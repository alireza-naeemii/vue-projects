<template>
  <div class="app">
    <h1>Vue To-Do App ✅</h1>
    <input v-model="newTask" @keyup.enter="addTask" placeholder="کار جدید رو وارد کن" />
    <button @click="addTask">افزودن</button>

    <ul>
      <li 
        v-for="(task, index) in tasks" 
        :key="index"
        :class="{ done: task.done }"
      >
        <span @click="toggleTask(index)">
          {{ task.text }}
        </span>
        <button @click="deleteTask(index)">❌</button>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      newTask: "",
      tasks: []
    };
  },
  methods: {
    addTask() {
      if (this.newTask.trim() !== "") {
        this.tasks.push({ text: this.newTask, done: false });
        this.newTask = "";
      }
    },
    toggleTask(index) {
      this.tasks[index].done = !this.tasks[index].done;
    },
    deleteTask(index) {
      this.tasks.splice(index, 1);
    }
  }
};
</script>

<style>
body {
  font-family: sans-serif;
  background: #f7f7f7;
  display: flex;
  justify-content: center;
  padding: 20px;
}
.app {
  background: #fff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  width: 300px;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 5px 0;
  padding: 5px;
  background: #f1f1f1;
  border-radius: 8px;
}
li.done span {
  text-decoration: line-through;
  color: gray;
}
input {
  width: 70%;
  padding: 5px;
}
button {
  margin-left: 5px;
  cursor: pointer;
}
</style>